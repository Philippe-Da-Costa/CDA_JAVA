package Darman.part6;

import java.util.Scanner;

public class Exo6_03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] tabNote=new int[9];
		System.out.print("Saisir une note sur 20 SVP :");
		for(int i=1;i<=9;i++) {
		
		tabNote[i]=sc.nextInt();
		sc.nextLine();}
		for( int notes:tabNote)
		System.out.println(notes);
		
		
		
		

	}

}
