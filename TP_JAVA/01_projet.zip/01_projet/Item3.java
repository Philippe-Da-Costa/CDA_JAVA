public class Item3 {
    public static void main(String[] args) {
       byte c = 50;
       byte d = 70;
	   byte e;
	   c=70;
	   e = (byte)( c + d);
        System.out.println("valeur de e: "+e);
    }
}