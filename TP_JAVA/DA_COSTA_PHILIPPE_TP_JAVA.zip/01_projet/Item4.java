public class Item4 {
    public static void main(String[] args) {
		System.out.println("resultat du calcul 1 : " + (  20.1 + 16.8) );
		//valeur affichée : 36.900000000000006
		
       System.out.println("resultat du calcul apres casting: " + (  20.1F + 16.8F) );
	   //Ici je cast avint de sortir un Float
    }
}