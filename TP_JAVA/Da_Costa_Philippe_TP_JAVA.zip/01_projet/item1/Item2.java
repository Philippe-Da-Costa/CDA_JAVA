public class Item2 {
    public static void main(String[] args) {
       int a = 1;
       int b = 1;
	   //ci dessous  le resultat est 2=11
        System.out.println(a + b + " = " + a + b);
		
		//ci dessous  le resultat est "1+1=2"
		System.out.println("\""+a+ " + " +b+ " = " +(a+b)+"\"");
		
    }
}