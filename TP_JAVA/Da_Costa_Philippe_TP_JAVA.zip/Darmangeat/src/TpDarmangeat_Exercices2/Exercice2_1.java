package TpDarmangeat_Exercices2;

public class Exercice2_1 {
	public static void main(String[] args) {
		double val = 231;
		double Double=val*2;
		System.out.println(val+"\n"+ Double);
	}

}
