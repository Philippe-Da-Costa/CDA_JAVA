/**
 * 
 */
/**
 * @author filou
 *
 */
module Darmangeat {
}