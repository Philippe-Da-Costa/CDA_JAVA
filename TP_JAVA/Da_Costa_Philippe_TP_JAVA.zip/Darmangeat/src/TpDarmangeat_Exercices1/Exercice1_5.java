package TpDarmangeat_Exercices1;

public class Exercice1_5 {
	public static void main(String[] args) {
		int A =5;
		int B =2;
		A =B;
		B =A;
		System.out.println("La variable A vaut: " +A+
				           "\nLa variable B vaut: "+B);
		
	}
}
