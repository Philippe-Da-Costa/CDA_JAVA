package TpDarmangeat_Exercices1;

public class Exercice1_9 {
	public static void main(String[] args) {
		String A="423";
		String B="12";
		String C=A&B;
		System.out.println(C);
	}//Erreur
}
