package TpDarmangeat_Exercices1;

public class Exercice1_3 {
	public static void main(String[] args) {
		int A=5;
		int B= A+4;
		A=A+1;
		B=A-4;
		System.out.println("La variable A est: "+A+
						   "\nLa variable B est: "+B	);
	}
}
