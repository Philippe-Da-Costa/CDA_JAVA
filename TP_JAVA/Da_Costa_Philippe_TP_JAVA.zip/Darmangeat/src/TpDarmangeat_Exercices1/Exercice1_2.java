package TpDarmangeat_Exercices1;

public class Exercice1_2 {
	public static void main(String[] args) {
		int A =5;
		int B =3;
		int C =A+B;
		A =2;
		C =B-A;
		System.out.println("La variable A vaut: " +A+
				           "\nLa variable B vaut: "+B+
				           "\nLa variable C vaut: "+C);
		
	}
}
